# Maze-Game
A puzzle game with the intention to let anyone have fun in addition to the ability to find solutions to problems as it sharpens visual intelligence, trains eye and hand coordination, and also trains one’s social skills.
We have used an algorithm known as "Growing Tree Algorithm" which helps in growing the network (walls of maze) in a new format on start of a every new game.
There's only one entry & exit point in the game where the main character trys to reach the final destination in the shortest period of time.
